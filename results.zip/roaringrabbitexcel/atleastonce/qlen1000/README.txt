Queues från 1 till 50
auto ack
persistent flag
msg size = 500
direct exchange
en producer/consumer per queue

q length 1000