Queues från 1 till 50
auto ack
persistent flag
msg size = 500
fanout exchange

en producer/consumer per queue