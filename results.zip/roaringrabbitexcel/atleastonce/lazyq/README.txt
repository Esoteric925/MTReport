Queues från 1 till 50
auto ack
persistent flag
msg size = 500
direct exchange
lazy queuee active
en producer/consumer per queue