Queues från 1 till 50
Manuell ack
persistent flag
msg size = 500
fanout exchange

en producer/consumer per queue