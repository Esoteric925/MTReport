Queues från 1 till 50

persistent flag
msg size = 500
direct exchange exchange

en producer/consumer per queue

queue length 100